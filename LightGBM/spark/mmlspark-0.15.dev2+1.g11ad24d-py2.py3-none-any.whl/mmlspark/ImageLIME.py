# Copyright (C) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in project root for information.


import sys
if sys.version >= '3':
    basestring = str

from pyspark.ml.param.shared import *
from pyspark import keyword_only
from pyspark.ml.util import JavaMLReadable, JavaMLWritable
from pyspark.ml.wrapper import JavaTransformer, JavaEstimator, JavaModel
from pyspark.ml.common import inherit_doc
from mmlspark.Utils import *
from mmlspark.TypeConversionUtils import generateTypeConverter, complexTypeConverter

@inherit_doc
class ImageLIME(ComplexParamsMixin, JavaMLReadable, JavaMLWritable, JavaTransformer):
    """


    Args:

        cellSize (double): Number that controls the size of the superpixels (default: 16.0)
        inputCol (str): The name of the input column
        labelCol (str): The name of the label column
        localModelPartitions (int): The number of partitions to coalesce to to fit the local model
        model (object): Model to try to locally approximate
        modelPartitions (int): The number of partitions to create for evaluating the model
        modifier (double): Controls the trade-off spatial and color distance (default: 130.0)
        nSamples (int): The number of samples to generate (default: 900)
        outputCol (str): The name of the output column
        samplingFraction (double): The fraction of superpixels to keep on (default: 0.3)
        superpixelCol (str): The column holding the superpixel decompositions (default: superpixels)
    """

    @keyword_only
    def __init__(self, cellSize=16.0, inputCol=None, labelCol=None, localModelPartitions=None, model=None, modelPartitions=None, modifier=130.0, nSamples=900, outputCol=None, samplingFraction=0.3, superpixelCol="superpixels"):
        super(ImageLIME, self).__init__()
        self._java_obj = self._new_java_obj("com.microsoft.ml.spark.ImageLIME")
        self._cache = {}
        self.cellSize = Param(self, "cellSize", "cellSize: Number that controls the size of the superpixels (default: 16.0)")
        self._setDefault(cellSize=16.0)
        self.inputCol = Param(self, "inputCol", "inputCol: The name of the input column")
        self.labelCol = Param(self, "labelCol", "labelCol: The name of the label column")
        self.localModelPartitions = Param(self, "localModelPartitions", "localModelPartitions: The number of partitions to coalesce to to fit the local model")
        self.model = Param(self, "model", "model: Model to try to locally approximate", generateTypeConverter("model", self._cache, complexTypeConverter))
        self.modelPartitions = Param(self, "modelPartitions", "modelPartitions: The number of partitions to create for evaluating the model")
        self.modifier = Param(self, "modifier", "modifier: Controls the trade-off spatial and color distance (default: 130.0)")
        self._setDefault(modifier=130.0)
        self.nSamples = Param(self, "nSamples", "nSamples: The number of samples to generate (default: 900)")
        self._setDefault(nSamples=900)
        self.outputCol = Param(self, "outputCol", "outputCol: The name of the output column")
        self.samplingFraction = Param(self, "samplingFraction", "samplingFraction: The fraction of superpixels to keep on (default: 0.3)")
        self._setDefault(samplingFraction=0.3)
        self.superpixelCol = Param(self, "superpixelCol", "superpixelCol: The column holding the superpixel decompositions (default: superpixels)")
        self._setDefault(superpixelCol="superpixels")
        if hasattr(self, "_input_kwargs"):
            kwargs = self._input_kwargs
        else:
            kwargs = self.__init__._input_kwargs
        self.setParams(**kwargs)

    @keyword_only
    def setParams(self, cellSize=16.0, inputCol=None, labelCol=None, localModelPartitions=None, model=None, modelPartitions=None, modifier=130.0, nSamples=900, outputCol=None, samplingFraction=0.3, superpixelCol="superpixels"):
        """
        Set the (keyword only) parameters

        Args:

            cellSize (double): Number that controls the size of the superpixels (default: 16.0)
            inputCol (str): The name of the input column
            labelCol (str): The name of the label column
            localModelPartitions (int): The number of partitions to coalesce to to fit the local model
            model (object): Model to try to locally approximate
            modelPartitions (int): The number of partitions to create for evaluating the model
            modifier (double): Controls the trade-off spatial and color distance (default: 130.0)
            nSamples (int): The number of samples to generate (default: 900)
            outputCol (str): The name of the output column
            samplingFraction (double): The fraction of superpixels to keep on (default: 0.3)
            superpixelCol (str): The column holding the superpixel decompositions (default: superpixels)
        """
        if hasattr(self, "_input_kwargs"):
            kwargs = self._input_kwargs
        else:
            kwargs = self.__init__._input_kwargs
        return self._set(**kwargs)

    def setCellSize(self, value):
        """

        Args:

            cellSize (double): Number that controls the size of the superpixels (default: 16.0)

        """
        self._set(cellSize=value)
        return self


    def getCellSize(self):
        """

        Returns:

            double: Number that controls the size of the superpixels (default: 16.0)
        """
        return self.getOrDefault(self.cellSize)


    def setInputCol(self, value):
        """

        Args:

            inputCol (str): The name of the input column

        """
        self._set(inputCol=value)
        return self


    def getInputCol(self):
        """

        Returns:

            str: The name of the input column
        """
        return self.getOrDefault(self.inputCol)


    def setLabelCol(self, value):
        """

        Args:

            labelCol (str): The name of the label column

        """
        self._set(labelCol=value)
        return self


    def getLabelCol(self):
        """

        Returns:

            str: The name of the label column
        """
        return self.getOrDefault(self.labelCol)


    def setLocalModelPartitions(self, value):
        """

        Args:

            localModelPartitions (int): The number of partitions to coalesce to to fit the local model

        """
        self._set(localModelPartitions=value)
        return self


    def getLocalModelPartitions(self):
        """

        Returns:

            int: The number of partitions to coalesce to to fit the local model
        """
        return self.getOrDefault(self.localModelPartitions)


    def setModel(self, value):
        """

        Args:

            model (object): Model to try to locally approximate

        """
        self._set(model=value)
        return self


    def getModel(self):
        """

        Returns:

            object: Model to try to locally approximate
        """
        return self._cache.get("model", None)


    def setModelPartitions(self, value):
        """

        Args:

            modelPartitions (int): The number of partitions to create for evaluating the model

        """
        self._set(modelPartitions=value)
        return self


    def getModelPartitions(self):
        """

        Returns:

            int: The number of partitions to create for evaluating the model
        """
        return self.getOrDefault(self.modelPartitions)


    def setModifier(self, value):
        """

        Args:

            modifier (double): Controls the trade-off spatial and color distance (default: 130.0)

        """
        self._set(modifier=value)
        return self


    def getModifier(self):
        """

        Returns:

            double: Controls the trade-off spatial and color distance (default: 130.0)
        """
        return self.getOrDefault(self.modifier)


    def setNSamples(self, value):
        """

        Args:

            nSamples (int): The number of samples to generate (default: 900)

        """
        self._set(nSamples=value)
        return self


    def getNSamples(self):
        """

        Returns:

            int: The number of samples to generate (default: 900)
        """
        return self.getOrDefault(self.nSamples)


    def setOutputCol(self, value):
        """

        Args:

            outputCol (str): The name of the output column

        """
        self._set(outputCol=value)
        return self


    def getOutputCol(self):
        """

        Returns:

            str: The name of the output column
        """
        return self.getOrDefault(self.outputCol)


    def setSamplingFraction(self, value):
        """

        Args:

            samplingFraction (double): The fraction of superpixels to keep on (default: 0.3)

        """
        self._set(samplingFraction=value)
        return self


    def getSamplingFraction(self):
        """

        Returns:

            double: The fraction of superpixels to keep on (default: 0.3)
        """
        return self.getOrDefault(self.samplingFraction)


    def setSuperpixelCol(self, value):
        """

        Args:

            superpixelCol (str): The column holding the superpixel decompositions (default: superpixels)

        """
        self._set(superpixelCol=value)
        return self


    def getSuperpixelCol(self):
        """

        Returns:

            str: The column holding the superpixel decompositions (default: superpixels)
        """
        return self.getOrDefault(self.superpixelCol)



    @classmethod
    def read(cls):
        """ Returns an MLReader instance for this class. """
        return JavaMMLReader(cls)

    @staticmethod
    def getJavaPackage():
        """ Returns package name String. """
        return "com.microsoft.ml.spark.ImageLIME"

    @staticmethod
    def _from_java(java_stage):
        module_name=ImageLIME.__module__
        module_name=module_name.rsplit(".", 1)[0] + ".ImageLIME"
        return from_java(java_stage, module_name)
