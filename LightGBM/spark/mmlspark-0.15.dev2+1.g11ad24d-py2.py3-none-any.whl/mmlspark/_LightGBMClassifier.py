# Copyright (C) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in project root for information.


import sys
if sys.version >= '3':
    basestring = str

from pyspark.ml.param.shared import *
from pyspark import keyword_only
from pyspark.ml.util import JavaMLReadable, JavaMLWritable
from pyspark.ml.wrapper import JavaTransformer, JavaEstimator, JavaModel
from pyspark.ml.common import inherit_doc
from mmlspark.Utils import *

@inherit_doc
class _LightGBMClassifier(ComplexParamsMixin, JavaMLReadable, JavaMLWritable, JavaEstimator):
    """


    Args:

        baggingFraction (double): Bagging fraction (default: 1.0)
        baggingFreq (int): Bagging frequency (default: 0)
        baggingSeed (int): Bagging seed (default: 3)
        categoricalColumns (list): List of categorical column names
        defaultListenPort (int): The default listen port on executors, used for testing (default: 12400)
        earlyStoppingRound (int): Early stopping round (default: 0)
        featureFraction (double): Feature fraction (default: 1.0)
        featuresCol (str): features column name (default: features)
        isUnbalance (bool): Set to true if training data is unbalanced in binary classification scenario (default: false)
        labelCol (str): label column name (default: label)
        learningRate (double): Learning rate or shrinkage rate (default: 0.1)
        maxBin (int): Max bin (default: 255)
        maxDepth (int): Max depth (default: -1)
        minSumHessianInLeaf (double): Minimal sum hessian in one leaf (default: 0.001)
        modelString (str): LightGBM model to retrain (default: )
        numIterations (int): Number of iterations, LightGBM constructs num_class * num_iterations trees (default: 100)
        numLeaves (int): Number of leaves (default: 31)
        objective (str): The Objective. For regression applications, this can be: regression_l2, regression_l1, huber, fair, poisson, quantile, mape, gamma or tweedie. For classification applications, this can be: binary, multiclass, or multiclassova.  (default: regression)
        parallelism (str): Tree learner parallelism, can be set to data_parallel or voting_parallel (default: data_parallel)
        predictionCol (str): prediction column name (default: prediction)
        probabilityCol (str): Column name for predicted class conditional probabilities. Note: Not all models output well-calibrated probability estimates! These probabilities should be treated as confidences, not precise probabilities (default: probability)
        rawPredictionCol (str): raw prediction (a.k.a. confidence) column name (default: rawPrediction)
        thresholds (object): Thresholds in multi-class classification to adjust the probability of predicting each class. Array must have length equal to the number of classes, with values > 0 excepting that at most one value may be 0. The class with largest value p/t is predicted, where p is the original probability of that class and t is the class's threshold
        timeout (double): Timeout in seconds (default: 120.0)
        verbosity (int): Verbosity where lt 0 is Fatal, eq 0 is Error, eq 1 is Info, gt 1 is Debug (default: 1)
        weightCol (str): The name of the weight column
    """

    @keyword_only
    def __init__(self, baggingFraction=1.0, baggingFreq=0, baggingSeed=3, categoricalColumns=None, defaultListenPort=12400, earlyStoppingRound=0, featureFraction=1.0, featuresCol="features", isUnbalance=False, labelCol="label", learningRate=0.1, maxBin=255, maxDepth=-1, minSumHessianInLeaf=0.001, modelString="", numIterations=100, numLeaves=31, objective="regression", parallelism="data_parallel", predictionCol="prediction", probabilityCol="probability", rawPredictionCol="rawPrediction", thresholds=None, timeout=120.0, verbosity=1, weightCol=None):
        super(_LightGBMClassifier, self).__init__()
        self._java_obj = self._new_java_obj("com.microsoft.ml.spark.LightGBMClassifier")
        self.baggingFraction = Param(self, "baggingFraction", "baggingFraction: Bagging fraction (default: 1.0)")
        self._setDefault(baggingFraction=1.0)
        self.baggingFreq = Param(self, "baggingFreq", "baggingFreq: Bagging frequency (default: 0)")
        self._setDefault(baggingFreq=0)
        self.baggingSeed = Param(self, "baggingSeed", "baggingSeed: Bagging seed (default: 3)")
        self._setDefault(baggingSeed=3)
        self.categoricalColumns = Param(self, "categoricalColumns", "categoricalColumns: List of categorical column names")
        self.defaultListenPort = Param(self, "defaultListenPort", "defaultListenPort: The default listen port on executors, used for testing (default: 12400)")
        self._setDefault(defaultListenPort=12400)
        self.earlyStoppingRound = Param(self, "earlyStoppingRound", "earlyStoppingRound: Early stopping round (default: 0)")
        self._setDefault(earlyStoppingRound=0)
        self.featureFraction = Param(self, "featureFraction", "featureFraction: Feature fraction (default: 1.0)")
        self._setDefault(featureFraction=1.0)
        self.featuresCol = Param(self, "featuresCol", "featuresCol: features column name (default: features)")
        self._setDefault(featuresCol="features")
        self.isUnbalance = Param(self, "isUnbalance", "isUnbalance: Set to true if training data is unbalanced in binary classification scenario (default: false)")
        self._setDefault(isUnbalance=False)
        self.labelCol = Param(self, "labelCol", "labelCol: label column name (default: label)")
        self._setDefault(labelCol="label")
        self.learningRate = Param(self, "learningRate", "learningRate: Learning rate or shrinkage rate (default: 0.1)")
        self._setDefault(learningRate=0.1)
        self.maxBin = Param(self, "maxBin", "maxBin: Max bin (default: 255)")
        self._setDefault(maxBin=255)
        self.maxDepth = Param(self, "maxDepth", "maxDepth: Max depth (default: -1)")
        self._setDefault(maxDepth=-1)
        self.minSumHessianInLeaf = Param(self, "minSumHessianInLeaf", "minSumHessianInLeaf: Minimal sum hessian in one leaf (default: 0.001)")
        self._setDefault(minSumHessianInLeaf=0.001)
        self.modelString = Param(self, "modelString", "modelString: LightGBM model to retrain (default: )")
        self._setDefault(modelString="")
        self.numIterations = Param(self, "numIterations", "numIterations: Number of iterations, LightGBM constructs num_class * num_iterations trees (default: 100)")
        self._setDefault(numIterations=100)
        self.numLeaves = Param(self, "numLeaves", "numLeaves: Number of leaves (default: 31)")
        self._setDefault(numLeaves=31)
        self.objective = Param(self, "objective", "objective: The Objective. For regression applications, this can be: regression_l2, regression_l1, huber, fair, poisson, quantile, mape, gamma or tweedie. For classification applications, this can be: binary, multiclass, or multiclassova.  (default: regression)")
        self._setDefault(objective="regression")
        self.parallelism = Param(self, "parallelism", "parallelism: Tree learner parallelism, can be set to data_parallel or voting_parallel (default: data_parallel)")
        self._setDefault(parallelism="data_parallel")
        self.predictionCol = Param(self, "predictionCol", "predictionCol: prediction column name (default: prediction)")
        self._setDefault(predictionCol="prediction")
        self.probabilityCol = Param(self, "probabilityCol", "probabilityCol: Column name for predicted class conditional probabilities. Note: Not all models output well-calibrated probability estimates! These probabilities should be treated as confidences, not precise probabilities (default: probability)")
        self._setDefault(probabilityCol="probability")
        self.rawPredictionCol = Param(self, "rawPredictionCol", "rawPredictionCol: raw prediction (a.k.a. confidence) column name (default: rawPrediction)")
        self._setDefault(rawPredictionCol="rawPrediction")
        self.thresholds = Param(self, "thresholds", "thresholds: Thresholds in multi-class classification to adjust the probability of predicting each class. Array must have length equal to the number of classes, with values > 0 excepting that at most one value may be 0. The class with largest value p/t is predicted, where p is the original probability of that class and t is the class's threshold")
        self.timeout = Param(self, "timeout", "timeout: Timeout in seconds (default: 120.0)")
        self._setDefault(timeout=120.0)
        self.verbosity = Param(self, "verbosity", "verbosity: Verbosity where lt 0 is Fatal, eq 0 is Error, eq 1 is Info, gt 1 is Debug (default: 1)")
        self._setDefault(verbosity=1)
        self.weightCol = Param(self, "weightCol", "weightCol: The name of the weight column")
        if hasattr(self, "_input_kwargs"):
            kwargs = self._input_kwargs
        else:
            kwargs = self.__init__._input_kwargs
        self.setParams(**kwargs)

    @keyword_only
    def setParams(self, baggingFraction=1.0, baggingFreq=0, baggingSeed=3, categoricalColumns=None, defaultListenPort=12400, earlyStoppingRound=0, featureFraction=1.0, featuresCol="features", isUnbalance=False, labelCol="label", learningRate=0.1, maxBin=255, maxDepth=-1, minSumHessianInLeaf=0.001, modelString="", numIterations=100, numLeaves=31, objective="regression", parallelism="data_parallel", predictionCol="prediction", probabilityCol="probability", rawPredictionCol="rawPrediction", thresholds=None, timeout=120.0, verbosity=1, weightCol=None):
        """
        Set the (keyword only) parameters

        Args:

            baggingFraction (double): Bagging fraction (default: 1.0)
            baggingFreq (int): Bagging frequency (default: 0)
            baggingSeed (int): Bagging seed (default: 3)
            categoricalColumns (list): List of categorical column names
            defaultListenPort (int): The default listen port on executors, used for testing (default: 12400)
            earlyStoppingRound (int): Early stopping round (default: 0)
            featureFraction (double): Feature fraction (default: 1.0)
            featuresCol (str): features column name (default: features)
            isUnbalance (bool): Set to true if training data is unbalanced in binary classification scenario (default: false)
            labelCol (str): label column name (default: label)
            learningRate (double): Learning rate or shrinkage rate (default: 0.1)
            maxBin (int): Max bin (default: 255)
            maxDepth (int): Max depth (default: -1)
            minSumHessianInLeaf (double): Minimal sum hessian in one leaf (default: 0.001)
            modelString (str): LightGBM model to retrain (default: )
            numIterations (int): Number of iterations, LightGBM constructs num_class * num_iterations trees (default: 100)
            numLeaves (int): Number of leaves (default: 31)
            objective (str): The Objective. For regression applications, this can be: regression_l2, regression_l1, huber, fair, poisson, quantile, mape, gamma or tweedie. For classification applications, this can be: binary, multiclass, or multiclassova.  (default: regression)
            parallelism (str): Tree learner parallelism, can be set to data_parallel or voting_parallel (default: data_parallel)
            predictionCol (str): prediction column name (default: prediction)
            probabilityCol (str): Column name for predicted class conditional probabilities. Note: Not all models output well-calibrated probability estimates! These probabilities should be treated as confidences, not precise probabilities (default: probability)
            rawPredictionCol (str): raw prediction (a.k.a. confidence) column name (default: rawPrediction)
            thresholds (object): Thresholds in multi-class classification to adjust the probability of predicting each class. Array must have length equal to the number of classes, with values > 0 excepting that at most one value may be 0. The class with largest value p/t is predicted, where p is the original probability of that class and t is the class's threshold
            timeout (double): Timeout in seconds (default: 120.0)
            verbosity (int): Verbosity where lt 0 is Fatal, eq 0 is Error, eq 1 is Info, gt 1 is Debug (default: 1)
            weightCol (str): The name of the weight column
        """
        if hasattr(self, "_input_kwargs"):
            kwargs = self._input_kwargs
        else:
            kwargs = self.__init__._input_kwargs
        return self._set(**kwargs)

    def setBaggingFraction(self, value):
        """

        Args:

            baggingFraction (double): Bagging fraction (default: 1.0)

        """
        self._set(baggingFraction=value)
        return self


    def getBaggingFraction(self):
        """

        Returns:

            double: Bagging fraction (default: 1.0)
        """
        return self.getOrDefault(self.baggingFraction)


    def setBaggingFreq(self, value):
        """

        Args:

            baggingFreq (int): Bagging frequency (default: 0)

        """
        self._set(baggingFreq=value)
        return self


    def getBaggingFreq(self):
        """

        Returns:

            int: Bagging frequency (default: 0)
        """
        return self.getOrDefault(self.baggingFreq)


    def setBaggingSeed(self, value):
        """

        Args:

            baggingSeed (int): Bagging seed (default: 3)

        """
        self._set(baggingSeed=value)
        return self


    def getBaggingSeed(self):
        """

        Returns:

            int: Bagging seed (default: 3)
        """
        return self.getOrDefault(self.baggingSeed)


    def setCategoricalColumns(self, value):
        """

        Args:

            categoricalColumns (list): List of categorical column names

        """
        self._set(categoricalColumns=value)
        return self


    def getCategoricalColumns(self):
        """

        Returns:

            list: List of categorical column names
        """
        return self.getOrDefault(self.categoricalColumns)


    def setDefaultListenPort(self, value):
        """

        Args:

            defaultListenPort (int): The default listen port on executors, used for testing (default: 12400)

        """
        self._set(defaultListenPort=value)
        return self


    def getDefaultListenPort(self):
        """

        Returns:

            int: The default listen port on executors, used for testing (default: 12400)
        """
        return self.getOrDefault(self.defaultListenPort)


    def setEarlyStoppingRound(self, value):
        """

        Args:

            earlyStoppingRound (int): Early stopping round (default: 0)

        """
        self._set(earlyStoppingRound=value)
        return self


    def getEarlyStoppingRound(self):
        """

        Returns:

            int: Early stopping round (default: 0)
        """
        return self.getOrDefault(self.earlyStoppingRound)


    def setFeatureFraction(self, value):
        """

        Args:

            featureFraction (double): Feature fraction (default: 1.0)

        """
        self._set(featureFraction=value)
        return self


    def getFeatureFraction(self):
        """

        Returns:

            double: Feature fraction (default: 1.0)
        """
        return self.getOrDefault(self.featureFraction)


    def setFeaturesCol(self, value):
        """

        Args:

            featuresCol (str): features column name (default: features)

        """
        self._set(featuresCol=value)
        return self


    def getFeaturesCol(self):
        """

        Returns:

            str: features column name (default: features)
        """
        return self.getOrDefault(self.featuresCol)


    def setIsUnbalance(self, value):
        """

        Args:

            isUnbalance (bool): Set to true if training data is unbalanced in binary classification scenario (default: false)

        """
        self._set(isUnbalance=value)
        return self


    def getIsUnbalance(self):
        """

        Returns:

            bool: Set to true if training data is unbalanced in binary classification scenario (default: false)
        """
        return self.getOrDefault(self.isUnbalance)


    def setLabelCol(self, value):
        """

        Args:

            labelCol (str): label column name (default: label)

        """
        self._set(labelCol=value)
        return self


    def getLabelCol(self):
        """

        Returns:

            str: label column name (default: label)
        """
        return self.getOrDefault(self.labelCol)


    def setLearningRate(self, value):
        """

        Args:

            learningRate (double): Learning rate or shrinkage rate (default: 0.1)

        """
        self._set(learningRate=value)
        return self


    def getLearningRate(self):
        """

        Returns:

            double: Learning rate or shrinkage rate (default: 0.1)
        """
        return self.getOrDefault(self.learningRate)


    def setMaxBin(self, value):
        """

        Args:

            maxBin (int): Max bin (default: 255)

        """
        self._set(maxBin=value)
        return self


    def getMaxBin(self):
        """

        Returns:

            int: Max bin (default: 255)
        """
        return self.getOrDefault(self.maxBin)


    def setMaxDepth(self, value):
        """

        Args:

            maxDepth (int): Max depth (default: -1)

        """
        self._set(maxDepth=value)
        return self


    def getMaxDepth(self):
        """

        Returns:

            int: Max depth (default: -1)
        """
        return self.getOrDefault(self.maxDepth)


    def setMinSumHessianInLeaf(self, value):
        """

        Args:

            minSumHessianInLeaf (double): Minimal sum hessian in one leaf (default: 0.001)

        """
        self._set(minSumHessianInLeaf=value)
        return self


    def getMinSumHessianInLeaf(self):
        """

        Returns:

            double: Minimal sum hessian in one leaf (default: 0.001)
        """
        return self.getOrDefault(self.minSumHessianInLeaf)


    def setModelString(self, value):
        """

        Args:

            modelString (str): LightGBM model to retrain (default: )

        """
        self._set(modelString=value)
        return self


    def getModelString(self):
        """

        Returns:

            str: LightGBM model to retrain (default: )
        """
        return self.getOrDefault(self.modelString)


    def setNumIterations(self, value):
        """

        Args:

            numIterations (int): Number of iterations, LightGBM constructs num_class * num_iterations trees (default: 100)

        """
        self._set(numIterations=value)
        return self


    def getNumIterations(self):
        """

        Returns:

            int: Number of iterations, LightGBM constructs num_class * num_iterations trees (default: 100)
        """
        return self.getOrDefault(self.numIterations)


    def setNumLeaves(self, value):
        """

        Args:

            numLeaves (int): Number of leaves (default: 31)

        """
        self._set(numLeaves=value)
        return self


    def getNumLeaves(self):
        """

        Returns:

            int: Number of leaves (default: 31)
        """
        return self.getOrDefault(self.numLeaves)


    def setObjective(self, value):
        """

        Args:

            objective (str): The Objective. For regression applications, this can be: regression_l2, regression_l1, huber, fair, poisson, quantile, mape, gamma or tweedie. For classification applications, this can be: binary, multiclass, or multiclassova.  (default: regression)

        """
        self._set(objective=value)
        return self


    def getObjective(self):
        """

        Returns:

            str: The Objective. For regression applications, this can be: regression_l2, regression_l1, huber, fair, poisson, quantile, mape, gamma or tweedie. For classification applications, this can be: binary, multiclass, or multiclassova.  (default: regression)
        """
        return self.getOrDefault(self.objective)


    def setParallelism(self, value):
        """

        Args:

            parallelism (str): Tree learner parallelism, can be set to data_parallel or voting_parallel (default: data_parallel)

        """
        self._set(parallelism=value)
        return self


    def getParallelism(self):
        """

        Returns:

            str: Tree learner parallelism, can be set to data_parallel or voting_parallel (default: data_parallel)
        """
        return self.getOrDefault(self.parallelism)


    def setPredictionCol(self, value):
        """

        Args:

            predictionCol (str): prediction column name (default: prediction)

        """
        self._set(predictionCol=value)
        return self


    def getPredictionCol(self):
        """

        Returns:

            str: prediction column name (default: prediction)
        """
        return self.getOrDefault(self.predictionCol)


    def setProbabilityCol(self, value):
        """

        Args:

            probabilityCol (str): Column name for predicted class conditional probabilities. Note: Not all models output well-calibrated probability estimates! These probabilities should be treated as confidences, not precise probabilities (default: probability)

        """
        self._set(probabilityCol=value)
        return self


    def getProbabilityCol(self):
        """

        Returns:

            str: Column name for predicted class conditional probabilities. Note: Not all models output well-calibrated probability estimates! These probabilities should be treated as confidences, not precise probabilities (default: probability)
        """
        return self.getOrDefault(self.probabilityCol)


    def setRawPredictionCol(self, value):
        """

        Args:

            rawPredictionCol (str): raw prediction (a.k.a. confidence) column name (default: rawPrediction)

        """
        self._set(rawPredictionCol=value)
        return self


    def getRawPredictionCol(self):
        """

        Returns:

            str: raw prediction (a.k.a. confidence) column name (default: rawPrediction)
        """
        return self.getOrDefault(self.rawPredictionCol)


    def setThresholds(self, value):
        """

        Args:

            thresholds (object): Thresholds in multi-class classification to adjust the probability of predicting each class. Array must have length equal to the number of classes, with values > 0 excepting that at most one value may be 0. The class with largest value p/t is predicted, where p is the original probability of that class and t is the class's threshold

        """
        self._set(thresholds=value)
        return self


    def getThresholds(self):
        """

        Returns:

            object: Thresholds in multi-class classification to adjust the probability of predicting each class. Array must have length equal to the number of classes, with values > 0 excepting that at most one value may be 0. The class with largest value p/t is predicted, where p is the original probability of that class and t is the class's threshold
        """
        return self.getOrDefault(self.thresholds)


    def setTimeout(self, value):
        """

        Args:

            timeout (double): Timeout in seconds (default: 120.0)

        """
        self._set(timeout=value)
        return self


    def getTimeout(self):
        """

        Returns:

            double: Timeout in seconds (default: 120.0)
        """
        return self.getOrDefault(self.timeout)


    def setVerbosity(self, value):
        """

        Args:

            verbosity (int): Verbosity where lt 0 is Fatal, eq 0 is Error, eq 1 is Info, gt 1 is Debug (default: 1)

        """
        self._set(verbosity=value)
        return self


    def getVerbosity(self):
        """

        Returns:

            int: Verbosity where lt 0 is Fatal, eq 0 is Error, eq 1 is Info, gt 1 is Debug (default: 1)
        """
        return self.getOrDefault(self.verbosity)


    def setWeightCol(self, value):
        """

        Args:

            weightCol (str): The name of the weight column

        """
        self._set(weightCol=value)
        return self


    def getWeightCol(self):
        """

        Returns:

            str: The name of the weight column
        """
        return self.getOrDefault(self.weightCol)



    @classmethod
    def read(cls):
        """ Returns an MLReader instance for this class. """
        return JavaMMLReader(cls)

    @staticmethod
    def getJavaPackage():
        """ Returns package name String. """
        return "com.microsoft.ml.spark.LightGBMClassifier"

    @staticmethod
    def _from_java(java_stage):
        module_name=_LightGBMClassifier.__module__
        module_name=module_name.rsplit(".", 1)[0] + ".LightGBMClassifier"
        return from_java(java_stage, module_name)

    def _create_model(self, java_model):
        return _LightGBMClassificationModel(java_model)


class _LightGBMClassificationModel(ComplexParamsMixin, JavaModel, JavaMLWritable, JavaMLReadable):
    """
    Model fitted by :class:`_LightGBMClassifier`.

    This class is left empty on purpose.
    All necessary methods are exposed through inheritance.
    """

    @classmethod
    def read(cls):
        """ Returns an MLReader instance for this class. """
        return JavaMMLReader(cls)

    @staticmethod
    def getJavaPackage():
        """ Returns package name String. """
        return "com.microsoft.ml.spark.LightGBMClassificationModel"

    @staticmethod
    def _from_java(java_stage):
        module_name=_LightGBMClassificationModel.__module__
        module_name=module_name.rsplit(".", 1)[0] + ".LightGBMClassificationModel"
        return from_java(java_stage, module_name)

