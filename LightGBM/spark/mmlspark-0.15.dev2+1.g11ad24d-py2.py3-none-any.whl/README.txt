Microsoft ML for Apache Spark
=============================

This package contains the PySpark library for MMLSpark.

This library provides spark estimators, transformers, and utility functions
for machine learning on Spark.  For more complete documentation, refer to
the MMLSpark repo: https://github.com/Azure/mmlspark .
